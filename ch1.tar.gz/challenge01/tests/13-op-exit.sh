grep -q goat  tests/sample.txt && exit; echo one
grep -q flown tests/sample.txt && exit; echo two
