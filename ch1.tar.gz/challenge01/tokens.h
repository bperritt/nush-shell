#ifndef TOKENS_H
#define TOKENS_H
#include "list.h"
#include "ast.h"

ast* tokenize(char* cmds);

#endif
